<template>
  <div>
    <show-report></show-report>
  </div>
</template>

<script>
import ShowReport from "../components/ShowReport.vue";

export default {
  components: { ShowReport },
};
</script>

<style scoped>
.page-title {
  display: flex;
  justify-content: center;
}
</style>
