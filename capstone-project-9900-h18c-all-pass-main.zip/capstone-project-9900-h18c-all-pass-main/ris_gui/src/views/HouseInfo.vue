<template>
    <div>
        <add-properties></add-properties>
    </div>
</template>

<script>
    import AddProperties from '../components/AddProperties.vue'
    export default{
        components: { AddProperties },
    }
</script>