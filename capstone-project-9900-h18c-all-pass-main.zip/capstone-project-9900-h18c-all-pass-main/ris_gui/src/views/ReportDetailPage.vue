<template>
    <div>
        <!-- <make-inspection></make-inspection> -->
        <report-detail></report-detail>
    </div>
</template>

<script>
    import ReportDetail from '../components/ReportDetail.vue'
    export default{
        components: { ReportDetail },
    }
</script>