<template>
  <div>
    <!-- <make-inspection></make-inspection> -->
    <report-modify></report-modify>
  </div>
</template>

<script>
import ReportModify from "../components/ReportModify.vue";
export default {
  components: { ReportModify },
};
</script>