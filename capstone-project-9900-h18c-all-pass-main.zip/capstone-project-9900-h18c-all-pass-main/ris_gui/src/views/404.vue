<template>
    <div class="not-found">
        404: Page Not Found
    </div>
</template>

<script>
export default {
    name: "404"
}
</script>