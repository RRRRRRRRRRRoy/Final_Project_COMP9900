<template>
    <div>
        <!-- <make-inspection></make-inspection> -->
        <report-plan></report-plan>
    </div>
</template>

<script>
    import ReportPlan from '../components/ReportAndPlan.vue'
    export default{
        components: { ReportPlan },
    }
</script>