<template>
    <div>
        <show-properties></show-properties>
    </div>
</template>

<script>
    import ShowProperties from '../components/ShowProperties.vue'
    export default{
        components: { ShowProperties },
    }
</script>