<template>
    <div>
        <property-detail></property-detail>
    </div>
</template>

<script>
    import propertyDetail from '../components/propertyDetail.vue'
    export default{
        components: { propertyDetail },
    }
</script>