<template>
    <div>
        <!-- <make-inspection></make-inspection> -->
        <create-report></create-report>
    </div>
</template>

<script>
    import CreateReport from '../components/CreateReport.vue'
    export default{
        components: { CreateReport },
    }
</script>