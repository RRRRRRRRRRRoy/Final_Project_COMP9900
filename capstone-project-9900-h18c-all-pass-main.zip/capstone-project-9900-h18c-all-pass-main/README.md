﻿# capstone-project-9900-h18c-all-pass
# Team member
|name|zid|role|
|:-:|:-:|:-:|
Rong Zou |z5240414|Back-end </br>[Scrum Master]
Zihan Lin |z5271413|Front-end
Hongyi Luo |z5241868|Front-end
Ruixuan Zhao |z5243320|Back-end
Zhengyang Jia |z5239803|Back-end

